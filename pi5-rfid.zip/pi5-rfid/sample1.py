from SimpleMFRC522 import SimpleMFRC522

reader = SimpleMFRC522() # Create an object of the class MFRC522

while True:
    print('starting')
    print('Tap')
    #Getting rfid data 
    id, text = reader.read()
    print(id)